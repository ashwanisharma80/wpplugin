<?php
/**
 * @package Productselector
 * @version 1.0
 */
/*
  Plugin Name: Productselector_Plugin
  Plugin URI: http://agilewebrtc.com/
  Description: This plugin is used for selecting product
  Author: Ashwani Sharma
  Version: 1.0
  Author URI: http://agilewebrtc.com/
 */

if (!class_exists ('Productselector_Plugin')) {

    class Productselector_Plugin {

        public $_name;
        public $page_title;
        public $page_name;
        public $page_id;

        public function __construct () {
            $this->_name = 'Product Finder';
            $this->page_title = 'Product Finder';
            $this->page_name = $this->_name;
            $this->page_id = '0';

            register_activation_hook (__FILE__, array ($this, 'activate'));
            register_deactivation_hook (__FILE__, array ($this, 'deactivate'));
            register_uninstall_hook (__FILE__, array ($this, 'uninstall'));
            add_action ('admin_menu', array ($this, 'ProductSelector_Form'));
            add_filter ('parse_query', array ($this, 'query_parser'));
            add_filter ('the_posts', array ($this, 'page_filter'));
        }

        static function step1 () {
            return '
                  <meta name="viewport" content="width=device-width, initial-scale=1">
                <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">
                <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
                <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>

                <div role="tabpanel">
                    <!-- Nav tabs -->
                    <ul class="nav nav-tabs" role="tablist">
                      <li role="presentation" class="active"><a href="#home" aria-controls="home" role="tab" data-toggle="tab">What do you need?</a></li>
                     </ul>

                    <!-- Tab panes -->
                    <div class="tab-content">
                      <div role="tabpanel" class="tab-pane active" id="home">
                        <ul>
                        <li>Air Conditioning</li>
                        <li>Heating</li>
                        <li>Both</li>
                        </ul>
                       </div>
                    </div>

                  </div>

           ';
        }

        function ProductSelector_Form () {
            add_options_page ("Product Finder", "Product Finder", 1, "productfinder", array ($this, "productselector_form_view"));
        }

        function productselector_form_view () {
            if ($_POST['productfinder_hidden'] == 'Y') {
                //Form data sent
                $dbhost = $_POST['productfinder_dbhost'];
                update_option ('productfinder_dbhost', $dbhost);

                $dbname = $_POST['productfinder_dbname'];
                update_option ('productfinder_dbname', $dbname);

                $dbuser = $_POST['productfinder_dbuser'];
                update_option ('productfinder_dbuser', $dbuser);

                $dbpwd = $_POST['productfinder_dbpwd'];
                update_option ('productfinder_dbpwd', $dbpwd);

                $prod_img_folder = $_POST['productfinder_prod_img_folder'];
                update_option ('productfinder_prod_img_folder', $prod_img_folder);

                $store_url = $_POST['productfinder_store_url'];
                update_option ('productfinder_store_url', $store_url);
                ?>
                <div class="updated"><p><strong><?php _e ('Options saved.'); ?></strong></p></div>
                <?php
            } else {
                //Normal page display
            }
            ?>
            <style>
                * {
                    .border-radius(0) !important;
                }

                #field {
                    margin-bottom:20px;
                }
            </style>
            <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
            <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>

            <script>

                $(document).ready(function () {
                    var next = 1;
                    $(".add-more-step1").click(function (e) {
                        e.preventDefault();
                        var addto = "#step1field" + next;
                        var addRemove = "#step1field" + (next);
                        next = next + 1;
                        var newIn = '<input autocomplete="off" class="input" id="step1field' + next + '" name="step1fields[]" type="text">';
                        var newInput = $(newIn);
                        var removeBtn = '<button id="stepremove' + (next - 1) + '" class="btn btn-danger remove-me-step1" >-</button></div><div id="field">';
                        var removeButton = $(removeBtn);
                        $(addto).after(newInput);
                        $(addRemove).after(removeButton);
                        $("#step1field" + next).attr('data-source', $(addto).attr('data-source'));
                        $("#count").val(next);

                        $('.remove-me-step1').click(function (e) {
                            e.preventDefault();
                            var fieldNum = this.id.charAt(this.id.length - 1);
                            var fieldID = "#step1field" + fieldNum;
                            $(this).remove();
                            $(fieldID).remove();
                        });
                    });
                    //step2
                    var next2 = 1;
                    $(".add-more-step2").click(function (e) {
                        e.preventDefault();
                        var addto = "#step2field" + next;
                        var addRemove = "#step2field" + (next);
                        next2 = next2 + 1;
                        var newIn = '<input autocomplete="off" class="input" id="step2field' + next2 + '" name="step2fields[]" type="text">';
                        var newInput = $(newIn);
                        var removeBtn = '<button id="step2remove' + (next2 - 1) + '" class="btn btn-danger remove-me-step2" >-</button></div><div id="field">';
                        var removeButton = $(removeBtn);
                        $(addto).after(newInput);
                        $(addRemove).after(removeButton);
                        $("#step2field" + next).attr('data-source', $(addto).attr('data-source'));
                        $("#count").val(next);

                        $('.remove-me-step2').click(function (e) {
                            e.preventDefault();
                            var fieldNum = this.id.charAt(this.id.length - 1);
                            var fieldID = "#step2field" + fieldNum;
                            $(this).remove();
                            $(fieldID).remove();
                        });
                    });
                    //step3
                    var next3 = 1;
                    $(".add-more-step3").click(function (e) {
                        e.preventDefault();
                        var addto = "#step3field" + next3;
                        var addRemove = "#step3field" + (next3);
                        next3 = next3 + 1;
                        var newIn = '<input autocomplete="off" class="input" id="step3field' + next3 + '" name="step3fields[]" type="text">';
                        var newInput = $(newIn);
                        var removeBtn = '<button id="step3remove' + (next3 - 1) + '" class="btn btn-danger remove-me-step3" >-</button></div><div id="field">';
                        var removeButton = $(removeBtn);
                        $(addto).after(newInput);
                        $(addRemove).after(removeButton);
                        $("#step3field" + next3).attr('data-source', $(addto).attr('data-source'));
                        $("#count").val(next3);

                        $('.remove-me-step3').click(function (e) {
                            e.preventDefault();
                            var fieldNum = this.id.charAt(this.id.length - 1);
                            var fieldID = "#step3field" + fieldNum;
                            $(this).remove();
                            $(fieldID).remove();
                        });
                    });
                    //step4
                    var next4=1;
                    $(".add-more-step4").click(function (e) {
                        e.preventDefault();
                        var addto = "#step4field" + next4;
                        var addRemove = "#step4field" + (next4);
                        next4 = next4 + 1;
                        var newIn = '<input autocomplete="off" class="input" id="step4field' + next4 + '" name="step4fields[]" type="text">';
                        var newInput = $(newIn);
                        var removeBtn = '<button id="step4remove' + (next4 - 1) + '" class="btn btn-danger remove-me-step4" >-</button></div><div id="field">';
                        var removeButton = $(removeBtn);
                        $(addto).after(newInput);
                        $(addRemove).after(removeButton);
                        $("#step4field" + next).attr('data-source', $(addto).attr('data-source'));
                        $("#count").val(next4);

                        $('.remove-me-step4').click(function (e) {
                            e.preventDefault();
                            var fieldNum = this.id.charAt(this.id.length - 1);
                            var fieldID = "#step4field" + fieldNum;
                            $(this).remove();
                            $(fieldID).remove();
                        });
                    });
                    //step5
                    var next5A=1;
                    var next5B=1;
                    $(".add-more-step5A").click(function (e) {
                        e.preventDefault();
                        var addto = "#step5Afield" + next5A;
                        var addRemove = "#step5Afield" + (next5A);
                        next5A = next5A + 1;
                        var newIn = '<input autocomplete="off" class="input" id="step5Afield' + next5A + '" name="step5Afields[]" type="text">';
                        var newInput = $(newIn);
                        var removeBtn = '<button id="step5Aremove' + (next5A - 1) + '" class="btn btn-danger remove-me-step5A" >-</button></div><div id="field">';
                        var removeButton = $(removeBtn);
                        $(addto).after(newInput);
                        $(addRemove).after(removeButton);
                        $("#step5Afield" + next5A).attr('data-source', $(addto).attr('data-source'));
                        $("#count").val(next5A);

                        $('.remove-me-step5A').click(function (e) {
                            e.preventDefault();
                            var fieldNum = this.id.charAt(this.id.length - 1);
                            var fieldID = "#step5Afield" + fieldNum;
                            $(this).remove();
                            $(fieldID).remove();
                        });
                    });
                    //step6
                    $(".add-more-step6").click(function (e) {
                        e.preventDefault();
                        var addto = "#step6field" + next;
                        var addRemove = "#step6field" + (next);
                        next = next + 1;
                        var newIn = '<input autocomplete="off" class="input" id="step6field' + next + '" name="step6fields[]" type="text">';
                        var newInput = $(newIn);
                        var removeBtn = '<button id="step6remove' + (next - 1) + '" class="btn btn-danger remove-me-step6" >-</button></div><div id="field">';
                        var removeButton = $(removeBtn);
                        $(addto).after(newInput);
                        $(addRemove).after(removeButton);
                        $("#step6field" + next).attr('data-source', $(addto).attr('data-source'));
                        $("#count").val(next);

                        $('.remove-me-step6').click(function (e) {
                            e.preventDefault();
                            var fieldNum = this.id.charAt(this.id.length - 1);
                            var fieldID = "#step6field" + fieldNum;
                            $(this).remove();
                            $(fieldID).remove();
                        });
                    });
                });
            </script>
            <div class="wrap">
                <?php echo "<h2>" . __ ('Product Finder Steps', 'productfinder_trdom') . "</h2>"; ?>

                <form name="product_finder_form" method="post" action="<?php echo str_replace ('%7E', '~', $_SERVER['REQUEST_URI']); ?>">
                    <input type="hidden" name="productfinder_hidden" value="Y">
                    <?php echo "<h4>" . __ ('Product Finder Steps', 'productfinder_trdom') . "</h4>"; ?>
                    <div class="container">
                        <div class="row">
                            <input type="hidden" name="count" value="1" />
                            <div class="control-group" id="fields">
                                <div class="controls" id="step1">
                                    <div> I. What do you need? </div>
                                    <div id="field">Option:<br /><input autocomplete="off" class="input" id="step1field1" name="step1fields[]" type="text" placeholder="Type something" data-items="8"/><button id="b1" class="btn add-more-step1" type="button">+</button></div>
                                    <br>
                                    <small>Press + to add another form field :)</small>
                                </div>
                                <div class="controls" id="step2">
                                    <div>II. Where do you need it? </div>
                                    <div id="field">Option:<br /><input autocomplete="off" class="input" id="step2field1" name="step2fields[]" type="text" placeholder="Type something" data-items="9"/><button id="b1" class="btn add-more-step2" type="button">+</button></div>
                                    <br>
                                    <small>Press + to add another form field :)</small>
                                </div>
                                <div class="controls" id="step3">
                                    <div> III. Which picture most closely resembles your current system </div>
                                    <div id="field">Option:<br /><input autocomplete="off" class="input" id="step3field1" name="step3fields[]" type="text" placeholder="Type something" data-items="10"/><button id="b1" class="btn add-more-step3" type="button">+</button></div>
                                    <br>
                                    <small>Press + to add another form field :)</small>
                                </div>
                                <div class="controls" id="step4">
                                    <div> IV. What type of system do you want?</div>
                                    <div id="field">Option:<br /><input autocomplete="off" class="input" id="step4field1" name="step4fields[]" type="text" placeholder="Type something" data-items="11"/><button id="b1" class="btn add-more-step4" type="button">+</button></div>
                                    <br>
                                    <small>Press + to add another form field :)</small>
                                </div>
                                <div class="controls" id="step5">
                                    <div>  V. Choose an efficiency level</div>
                                    <div> A. Air Conditioning</div>
                                    <div id="field">Option:<br /><input autocomplete="off" class="input" id="step5fieldA1" name="step5Afields[]" type="text" placeholder="Type something" data-items="12"/><button id="b1" class="btn add-more-step5A" type="button">+</button></div>
                                    <br>
                                    <small>Press + to add another form field :)</small>
                                    <div>  B. Heating</div>
                                    <div id="field">Option:<br /><input autocomplete="off" class="input" id="step5fieldB1" name="step5Bfields[]" type="text" placeholder="Type something" data-items="13"/><button id="b1" class="btn add-more-step5B" type="button">+</button></div>
                                    <br>
                                    <small>Press + to add another form field :)</small>
                                </div>
                                <div class="controls" id="step6">
                                    <div>  VI. I’d like to optimize for:</div>
                                    <div id="field">Option:<br /><input autocomplete="off" class="input" id="step6field1" name="step6fields[]" type="text" placeholder="Type something" data-items="14"/><button id="b1" class="btn add-more-step6" type="button">+</button></div>
                                    <br>
                                    <small>Press + to add another form field :)</small>
                                </div>
                            </div>
                        </div>
                    </div>

                    <p class="submit">
                        <input type="submit" name="Submit" value="<?php _e ('Update Options', 'productfinder_trdom') ?>" />
                    </p>
                </form>
            </div>
            <?php
        }

        public function activate () {
            global $wpdb;

            delete_option ($this->_name . '_page_title');
            add_option ($this->_name . '_page_title', $this->page_title, '', 'yes');

            delete_option ($this->_name . '_page_name');
            add_option ($this->_name . '_page_name', $this->page_name, '', 'yes');

            delete_option ($this->_name . '_page_id');
            add_option ($this->_name . '_page_id', $this->page_id, '', 'yes');

            $the_page = get_page_by_title ($this->page_title);

            if (!$the_page) {
                // Create post object
                $_p = array ();
                $_p['post_title'] = $this->page_title;
                $_p['post_content'] = $this->step1 ();
                $_p['post_status'] = 'publish';
                $_p['post_type'] = 'page';
                $_p['comment_status'] = 'closed';
                $_p['ping_status'] = 'closed';
                //  $_p['post_category'] = array (1); // the default 'Uncatrgorised'
                // Insert the post into the database
                $this->page_id = wp_insert_post ($_p);
            } else {
                // the plugin may have been previously active and the page may just be trashed...
                $this->page_id = $the_page->ID;

                //make sure the page is not trashed...
                $the_page->post_status = 'publish';
                $this->page_id = wp_update_post ($the_page);
            }

            delete_option ($this->_name . '_page_id');
            add_option ($this->_name . '_page_id', $this->page_id);
        }

        public function deactivate () {
            $this->deletePage ();
            $this->deleteOptions ();
        }

        public function uninstall () {
            $this->deletePage (true);
            $this->deleteOptions ();
        }

        public function query_parser ($q) {
            if (isset ($q->query_vars['page_id']) AND ( intval ($q->query_vars['page_id']) == $this->page_id )) {
                $q->set ($this->_name . '_page_is_called', true);
            } elseif (isset ($q->query_vars['pagename']) AND ( ($q->query_vars['pagename'] == $this->page_name) OR ( $_pos_found = strpos ($q->query_vars['pagename'], $this->page_name . '/') === 0))) {
                $q->set ($this->_name . '_page_is_called', true);
            } else {
                $q->set ($this->_name . '_page_is_called', false);
            }
        }

        function page_filter ($posts) {
            global $wp_query;

            if ($wp_query->get ($this->_name . '_page_is_called')) {
                $posts[0]->post_title = __ ('');
                $posts[0]->post_content = $this->step1 ();
            }
            return $posts;
        }

        private function deletePage ($hard = false) {
            global $wpdb;

            $id = get_option ($this->_name . '_page_id');
            if ($id && $hard == true)
                wp_delete_post ($id, true);
            elseif ($id && $hard == false)
                wp_delete_post ($id);
        }

        private function deleteOptions () {
            delete_option ($this->_name . '_page_title');
            delete_option ($this->_name . '_page_name');
            delete_option ($this->_name . '_page_id');
        }

    }

}
$Productselector_Plugin_obj = new Productselector_Plugin();
